$(document).ready(function() {
	
	$("SELECT").selectBox();	
	
})














