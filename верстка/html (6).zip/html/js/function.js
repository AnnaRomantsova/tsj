$(document).ready(function() {
	
	$("SELECT").selectBox();	
	
	$("#closePopup").click(function(){
		$(".zalivka").hide(500);
		$(".popupWindow").hide(500);
	})
	
	
})














